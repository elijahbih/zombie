# Godot Zombie Game

Uses Godot 4, this is the first game I've ever made using Godot. It's very simple.

You have an endless wave of zombies. You can shoot them.

They sometimes drop a health kit.

They will hurt you.

## Preview

[![Demo](https://i.ytimg.com/vi/dMBbb_BKyBs/hqdefault.jpg)](https://www.youtube.com/watch?v=dMBbb_BKyBs)

## Try

[https://stuyk.itch.io/zombie-shootin](https://stuyk.itch.io/zombie-shootin)
